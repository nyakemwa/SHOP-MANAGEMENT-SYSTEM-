from django.apps import AppConfig


class UkumbiConfig(AppConfig):
    name = 'ukumbi'
